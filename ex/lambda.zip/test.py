
def handler(event, context):

    print("event:{}\ncontext{}\n".format(event, context))